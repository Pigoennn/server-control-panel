import os
from pathlib import Path

def generate_mod_list():
    # Get the folder where this script is located
    mods_dir = Path(__file__).resolve().parent
    output_file = mods_dir / "mod_list.txt"

    active_mods = []
    disabled_mods = []

    for item in mods_dir.iterdir():
        if item.is_file():
            if item.name.endswith(".jar"):
                active_mods.append(item.name)
            elif item.name.endswith(".jar.disabled"):
                disabled_mods.append(item.name)

    # Sort alphabetically (case-insensitive)
    active_mods.sort(key=str.lower)
    disabled_mods.sort(key=str.lower)

    with open(output_file, "w", encoding="utf-8") as f:
        f.write(f"=== ACTIVE MODS ({len(active_mods)}) ===\n")
        for mod in active_mods:
            f.write(f"{mod}\n")

        if disabled_mods:
            f.write(f"\n=== DISABLED MODS ({len(disabled_mods)}) ===\n")
            for mod in disabled_mods:
                f.write(f"{mod}\n")

    print(f"Done! Found {len(active_mods)} active mods.")
    print(f"Saved list to: {output_file}")

if __name__ == "__main__":
    generate_mod_list()
